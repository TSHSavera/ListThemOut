//WALA NG GAGALAW NETO!!!
#include "views.h"
int main() {new views();}